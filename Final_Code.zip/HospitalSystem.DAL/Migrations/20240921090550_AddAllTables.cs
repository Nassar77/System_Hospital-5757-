﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace HospitalSystem.DAL.Migrations
{
    /// <inheritdoc />
    public partial class AddAllTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "8b5ad0b9-56ba-4e61-9f45-e07a2cd7b118");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "a013f723-310d-4bb6-80ab-51656246059d");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "f97e0cda-ecfb-4675-9942-8dfc96c359ed");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "18367fe1-ed18-4a37-b0df-50c827e5a58a", "c1d0d12e-bf7e-4975-bfe4-94b714a9a6c4", "Doctor", "doctor" },
                    { "382d688e-8f29-44f3-869f-7acaa6cbe9f9", "a731cadb-196f-4852-996a-6d7634af983b", "Admin", "admin" },
                    { "b2992580-9ca6-425c-8e43-a4ad51dc28ba", "81d9de4f-235e-480a-83b9-116264492e32", "Patient", "patient" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "18367fe1-ed18-4a37-b0df-50c827e5a58a");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "382d688e-8f29-44f3-869f-7acaa6cbe9f9");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "b2992580-9ca6-425c-8e43-a4ad51dc28ba");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "8b5ad0b9-56ba-4e61-9f45-e07a2cd7b118", "2ca6f42b-76c0-4551-872d-6fa9d8f84efb", "Doctor", "doctor" },
                    { "a013f723-310d-4bb6-80ab-51656246059d", "f55f7376-891a-4206-b887-0945a67bd1c6", "Patient", "patient" },
                    { "f97e0cda-ecfb-4675-9942-8dfc96c359ed", "43d17596-5870-4dae-aedb-f0b04e56f96e", "Admin", "admin" }
                });
        }
    }
}
