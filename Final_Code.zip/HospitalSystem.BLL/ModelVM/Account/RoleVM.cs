﻿

namespace HospitalSystem.BLL.ModelVM.Account
{
    public class RoleVM
    {
        public string? roleId { get; set; }
        public string? roleName { get; set; }
        public bool useRole { get; set; }
    }

}
